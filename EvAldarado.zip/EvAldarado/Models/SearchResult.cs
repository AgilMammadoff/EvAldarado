﻿namespace PropertySearch.Models
{
	public class SearchResult
	{
		public string Title { get; set; }
		public string Location { get; set; }
		public string Price { get; set; }
	}
}
