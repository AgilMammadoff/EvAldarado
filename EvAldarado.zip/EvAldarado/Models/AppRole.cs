﻿using Microsoft.AspNetCore.Identity;

namespace EvAldarado.Models
{
    public class AppRole : IdentityRole
    {
    }
}
