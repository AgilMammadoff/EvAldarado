﻿namespace EvAldarado.ViewModels
{
    public class Role
    {
        public string Name { get; set; }
    }
}
