﻿namespace EvAldarado.ViewModels
{
    public class AssignRole
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public bool Status { get; set; }
    }
}
