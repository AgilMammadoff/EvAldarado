﻿using EvAldarado.Models;

namespace EvAldarado.ViewModels
{
    public class HomeViewModel
    {
        public List<Slider> Sliders { get; set; }
        public List<UserProducts> UserProducts { get; set; }
    }
}
